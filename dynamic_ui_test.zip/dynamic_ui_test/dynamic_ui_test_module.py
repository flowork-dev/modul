# dev :  awenk audico
# EMAIL SAHIDINAOLA@GMAIL.COM
# WEBSITE WWW.TEETAH.ART
# File NAME : dynamic_ui_test/dynamic_ui_test_module.py

import ttkbootstrap as ttk
from flowork_kernel.api_contract import BaseModule, BaseUIProvider
from flowork_kernel.ui_shell.custom_tab import CustomTab # Kita akan menggunakan CustomTab yang sudah ada

class DynamicUITestModule(BaseModule, BaseUIProvider):
    """
    Modul contoh ini mengimplementasikan BaseUIProvider untuk mendemonstrasikan
    penambahan tab UI dan item menu secara dinamis.
    """
    def __init__(self, module_id, services):
        # PERBAIKAN: Menyesuaikan __init__ dengan kontrak dan memanggil super() dengan benar.
        super().__init__(module_id, services)
        # BaseModule.__init__ sudah otomatis mengatur self.logger, self.loc, dan self.kernel

        # PERBAIKAN: Menggunakan self.logger yang sudah disuntikkan secara langsung
        self.logger(f"Modul Tes UI Dinamis '{self.module_id}' diinisialisasi.", "DEBUG")

    def on_load(self):
        """
        Dipanggil saat modul dimuat atau aplikasi dimulai.
        """
        self.logger(f"Modul Tes UI Dinamis '{self.module_id}' (v1.0.0) dimuat (on_load).", "INFO")

    def on_unload(self):
        """
        Dipanggil tepat sebelum modul dibongkar (dijeda/dihapus).
        """
        self.logger(f"Modul Tes UI Dinamis '{self.module_id}' sedang dibongkar (on_unload).", "INFO")

    def execute(self, payload, config, status_updater, ui_callback, mode='EXECUTE'):
        """
        Metode execute untuk modul ini (meskipun ini modul UI, tetap harus diimplementasikan).
        PERBAIKAN: Menambahkan parameter mode='EXECUTE' agar sesuai kontrak.
        """
        self.logger("Metode 'execute' dipanggil di Modul Tes UI Dinamis.", "INFO")
        status_updater("Selesai (Modul UI)", "SUCCESS")
        return payload # Mengembalikan payload yang sama

    def get_ui_tabs(self):
        """
        Mengembalikan daftar definisi tab kustom yang akan ditambahkan ke UI utama.
        """
        self.logger(f"Modul '{self.module_id}' menyediakan definisi tab UI.", "INFO")
        return [
            {
                "title": self.loc.get('dynamic_test_tab_title', fallback="Tab Tes Dinamis"),
                "frame_class": CustomTab # Menggunakan kelas CustomTab yang sudah ada
            }
        ]

    def get_menu_items(self):
        """
        Mengembalikan daftar definisi item menu yang akan ditambahkan ke menubar utama.
        """
        self.logger(f"Modul '{self.module_id}' menyediakan definisi item menu UI.", "INFO")
        # PERBAIKAN: Menggunakan self.kernel yang sudah disuntikkan
        return [
            {
                "parent": "Pengaturan", # Menentukan menu utama tempat item ini akan muncul
                "label": self.loc.get('open_dynamic_test_tab_menu', fallback="Buka Tab Tes Dinamis"),
                "command": lambda: self.kernel.ui_add_tab(self.loc.get('dynamic_test_tab_title', fallback="Tab Tes Dinamis"), CustomTab)
            }
        ]